using UnityEngine;

public class Ball : MonoBehaviour
{
    [SerializeField] private float speed = 7f;
    private Rigidbody2D rb;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        LuncurkanBola();
    }

    public void LuncurkanBola()
    {
        // Pindahkan bola ke tengah dulu
        transform.position = Vector2.zero;

        // Pilih arah acak ke kiri/kanan dan atas/bawah
        float x = Random.Range(0, 2) == 0 ? -1 : 1;
        float y = Random.Range(0, 2) == 0 ? -1 : 1;

        // Kasih kecepatan awal (Velocity)
        // Gunakan rb.velocity jika Unity versi lama, atau rb.linearVelocity untuk Unity 6
        rb.linearVelocity = new Vector2(x * speed, y * speed);
    }

    // Cukup satu saja fungsi deteksi tabrakan (Trigger)
    private void OnTriggerEnter2D(Collider2D collision)
    {
        // Jika bola menabrak objek dengan Tag "Goal"
        if (collision.gameObject.CompareTag("Goal"))
        {
            // Mencari objek GameManager dan lapor kalau ada gol
            GameManager gm = FindObjectOfType<GameManager>();
            if (gm != null)
            {
                gm.GoalReached(collision.name);
            }
        }
    }
}