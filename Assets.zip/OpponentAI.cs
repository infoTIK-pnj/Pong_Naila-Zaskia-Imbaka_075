using UnityEngine;

public class OpponentAI : MonoBehaviour
{
    [SerializeField] private float speed = 5f;
    [SerializeField] private Transform ball; // Tempat naruh bola nanti

    void Update()
    {
        if (ball != null)
        {
            // AI ini akan ngejar posisi Y (atas/bawah) bola
            float targetY = Mathf.MoveTowards(transform.position.y, ball.position.y, speed * Time.deltaTime);
            transform.position = new Vector3(transform.position.x, targetY, 0);
        }
    }
}