using UnityEngine;

public class PlayerPaddle : MonoBehaviour
{
    // SerializeField biar bisa ganti kecepatan di Unity tanpa buka kodingan lagi
    [SerializeField] private float speed = 10f;

    void Update()
    {
        // Mengambil input tombol W/S atau Panah Atas/Bawah
        float moveInput = Input.GetAxisRaw("Vertical");

        // Rumus gerak: posisi + (arah * kecepatan * waktu)
        transform.position += new Vector3(0, moveInput * speed * Time.deltaTime, 0);
    }
}