using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public int playerScore;
    public int opponentScore;
    public TextMeshProUGUI scoreText;
    [SerializeField] private Ball ballScript;

    public void GoalReached(string wallName)
    {
        // Kalau kena gawang kiri, berarti poin untuk musuh (kanan)
        if (wallName == "Left")
        {
            opponentScore++;
        }
        else // Kalau kena gawang kanan, berarti poin untuk pemain (kiri)
        {
            playerScore++;
        }

        scoreText.text = playerScore + " : " + opponentScore;

        // Cek pemenang 11 poin sesuai syarat UTS
        if (playerScore >= 11 || opponentScore >= 11)
        {
            Debug.Log("Permainan Berakhir!");
            // Opsional: kamu bisa tambahkan kode buat stop game di sini
        }
        else
        {
            ballScript.LuncurkanBola(); // Bola balik ke tengah
        }
    }
}